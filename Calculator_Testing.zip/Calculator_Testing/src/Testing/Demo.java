package Testing;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;


import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.service.local.AppiumDriverLocalService;

public class Demo {
	
	public static AndroidDriver<MobileElement>driver;
	public void Launch() throws MalformedURLException, InterruptedException
	{
		// Setting up the Desired Capabilities
		
		DesiredCapabilities cap =  new DesiredCapabilities();
		cap.setCapability("deviceName", "HKE6H90H");
		cap.setCapability("appPackage"," com.vbanthia.androidsampleapp");//com.touchboarder.android.api.demos
		cap.setCapability("appActivity", "com.vbanthia.androidsampleapp.MainActivity");//com.touchboarder.androidapidemos.MainActivity
		cap.setCapability("platformName", "Android");
		cap.setCapability("platformVersion", "6.0");
		cap.setCapability("deviceOrientation", "portrait");
		cap.setCapability("browserName", "");
		cap.setCapability("noReset", true);
	
		//Invoking Appium Server
		driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"),cap);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		//Checking Addition Functionality
		
		driver.findElement(By.id("com.vbanthia.androidsampleapp:id/inputFieldLeft")).sendKeys("10");
		driver.findElement(By.id("com.vbanthia.androidsampleapp:id/inputFieldRight")).sendKeys("10");
		driver.findElement(By.id("com.vbanthia.androidsampleapp:id/additionButton")).click();
		String Add =driver.findElement(By.id("com.vbanthia.androidsampleapp:id/resultTextView")).getText();
		System.out.println("The addition of two numbers is:"+Add);
		Thread.sleep(5000);
		
		//Checking the Reset functionality
		driver.findElement(By.id("com.vbanthia.androidsampleapp:id/resetButton")).click();
		Thread.sleep(5000);
		
		//Checking Multiplication Functionality
		driver.findElement(By.id("com.vbanthia.androidsampleapp:id/inputFieldLeft")).sendKeys("50");
		driver.findElement(By.id("com.vbanthia.androidsampleapp:id/inputFieldRight")).sendKeys("10");
		driver.findElement(By.id("com.vbanthia.androidsampleapp:id/multiplicationButton")).click();
		String Multiply =driver.findElement(By.id("com.vbanthia.androidsampleapp:id/resultTextView")).getText();
		System.out.println("The multiplication of two numbers is:"+Multiply);
		Thread.sleep(5000);
		
		driver.findElement(By.id("com.vbanthia.androidsampleapp:id/resetButton")).click();
		Thread.sleep(5000);
		
		//Checking Division Functionality
		driver.findElement(By.id("com.vbanthia.androidsampleapp:id/inputFieldLeft")).sendKeys("50");
		driver.findElement(By.id("com.vbanthia.androidsampleapp:id/inputFieldRight")).sendKeys("10");
		driver.findElement(By.id("com.vbanthia.androidsampleapp:id/divisionButton")).click();
		String Divide =driver.findElement(By.id("com.vbanthia.androidsampleapp:id/resultTextView")).getText();
		System.out.println("The division of two nunbers is:"+Divide);
		Thread.sleep(5000);
		
		driver.findElement(By.id("com.vbanthia.androidsampleapp:id/resetButton")).click();
		Thread.sleep(5000);
		
		//Verifying the validation message when User does not enters anything in the text boxes and clicks on Reset button
		if(driver.findElement(By.id("com.vbanthia.androidsampleapp:id/additionButton")).isDisplayed())
		{
		driver.findElement(By.id("com.vbanthia.androidsampleapp:id/additionButton")).click();
		String Message =driver.findElement(By.id("com.vbanthia.androidsampleapp:id/resultTextView")).getText();
		System.out.println("Validation Message Check:" +Message);
		}
		}
	public static void main( String[] args ) throws Exception
    {
		       
		Demo test = new Demo();
        test.Launch();
        driver.quit();     
    }
}
